# 🎯 Pixel CRM Demo

## 📱 Demo dell'applicazione Pixel CRM per FARMAP

### 🔐 Credenziali Demo
- **Email**: admin@admin.it
- **Password**: admin123

### 🚀 Funzionalità Demo
- ✅ Gestione Clienti
- ✅ Gestione Prodotti
- ✅ Listini Prezzi
- ✅ Ordini
- ✅ Campionatura
- ✅ Report
- ✅ Gestione Utenti

### 🏢 Dati Aziendali
- **Ragione Sociale**: FARMAP INDUSTRY S.r.l.
- **Indirizzo**: Via Nazionale, 66 - 65012 Cepagatti (PE)

### 📞 Contatto
- **Sito**: www.abruzzo.ai
- **Email**: info@abruzzo.ai

---
*Demo generata automaticamente - Sun Sep 14 23:10:33 CEST 2025*
